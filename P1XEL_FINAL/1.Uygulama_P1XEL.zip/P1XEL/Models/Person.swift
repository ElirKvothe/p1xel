//
//  Product.swift
//  RedBullApp
//
//  Created by Serenay Güneş on 27.04.2024.
//

import Foundation



struct Person: Identifiable {
    var id = UUID()
    var name: String
    var image: String
    var disciplines: String
}

var personList = [Person(name: "Deniz Öncü", image: "deniz", disciplines: "Moto2"),
                 Person(name: "Hande Baladın", image: "hande2", disciplines:  "Voleybol"),
                 Person(name: "Toprak Razgatlıoğlu", image: "toprak", disciplines: "Superbike"),
                 Person(name: "Bora Altıntaş", image: "bora", disciplines: "BMX Street"),
                 Person(name: "Ali Türkkan", image: "bahattin", disciplines: "Ralli"),
                 Person(name: "Ferit 'wtcN' Karaya", image: "ferit", disciplines:  "Gaming"),
                 Person(name: "Berke Dikişcioğlu", image: "berke", disciplines: "Kaykay"),
                 Person(name: "Bahattin Sofuoğlu", image: "ali", disciplines: "Supersport"),
                 Person(name: "Kübra Dağlı", image: "kubra", disciplines: "Taekwondo"),
                 Person(name: "Hazal Nehir", image: "hazal", disciplines:  "Parkur"),
                 Person(name: "İsmail 'İsoPowerr' CanYerinde", image: "ismail", disciplines: "E-spor"),
                 Person(name: "Can Öncü", image: "can", disciplines: "MotoGP"),]

/*
struct Person: Identifiable, Decodable {
    var id = UUID()
    var name: String
    var image: String
    var disciplines: String
    
    // Decode işlemi için CodingKeys tanımlanabilir
    enum CodingKeys: String, CodingKey {
        case name
        case image
        case disciplines
    }
    
    
     init(from decoder: Decoder) throws {
           let container = try decoder.container(keyedBy: CodingKeys.self)
           self.name = try container.decode(String.self, forKey: .name)
           self.image = try container.decode(String.self, forKey: .image)
           self.disciplines = try container.decode(String.self, forKey: .disciplines)
       }
     
}
*/

 
//

/*
struct Person: Identifiable, Decodable {
    var id = UUID()
    var name: String
    var image: String
    var disciplines: String
    
    enum CodingKeys: String, CodingKey {
        case name
        case image
        case disciplines
    }
    //bu kısım ne kadar gerekli çözemedim?
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.name = try container.decode(String.self, forKey: .name)
        self.image = try container.decode(String.self, forKey: .image)
        self.disciplines = try container.decode(String.self, forKey: .disciplines)
    }
   
}
*/
