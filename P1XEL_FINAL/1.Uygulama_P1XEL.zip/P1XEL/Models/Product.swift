//
//  Product.swift
//  RedBullApp
//
//  Created by Serenay Güneş on 27.04.2024.
//

import Foundation

struct Product: Identifiable {
    var id = UUID()
    var name: String
    var image: String
    var price: Int
}

var productList = [Product(name: "Redbull Enerji İçeceği", image: "urun1", price: 30),
                   Product(name: "Redbull Sugarfree", image: "urun2", price: 30),
                   Product(name: "Redbull White Edition", image: "urun3", price: 35),
                   Product(name: "Redbull Blue Edition", image: "urun4", price: 35),
                   Product(name: "Redbull Peach Edition", image: "urun5", price: 35),
                   Product(name: "Redbull Yellow Edition", image: "urun6", price: 35),
                   Product(name: "Redbull Red Edition", image: "urun7", price: 35),
                   Product(name: "Redbull Winter Edition", image: "urun8", price: 35)]








