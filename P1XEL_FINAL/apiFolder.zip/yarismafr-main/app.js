const express = require('express');
const bodyParser = require('body-parser');

const app = express();

const athleteRoute = require('./routes/athlete');
const userRoute = require('./routes/user');
const energydrinkRoute = require('./routes/energydrink');
const cartRoute = require('./routes/cart');

app.use(bodyParser.json());

app.use('/athlete', athleteRoute);
app.use('/user', userRoute);
app.use('/energydrink', energydrinkRoute);
app.use('/cart', cartRoute);

app.get('/', (req, res) => {
    res.send('Hello World!');
    });

module.exports = app;