const models = require('../models');

function index(req, res) {
    models.energydrinks.findAll().then(result => {
        res.status(200).json(result);
    }).catch(error => {
        res.status(500).json({
            message: 'Something went wrong',
            error: error
        });
    });
}

function show(req, res) {
    models.energydrinks.findByPk(req.params.id).then(result => {
        res.status(200).json(result);
    }).catch(error => {
        res.status(500).json({
            message: 'Something went wrong',
            error: error
        });
    });
}

module.exports = {
    show: show,
    index: index
};