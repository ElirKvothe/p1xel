const express = require('express');
const athleteController = require('../controllers/athlete.controller');

const router = express.Router();

router.get('/', athleteController.index);
router.get('/:id', athleteController.show);

module.exports = router;