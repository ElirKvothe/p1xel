const express = require('express');
const energydrinkController = require('../controllers/energydrink.controller');

const router = express.Router();

router.get('/', energydrinkController.index);
router.get('/:id', energydrinkController.show);

module.exports = router;